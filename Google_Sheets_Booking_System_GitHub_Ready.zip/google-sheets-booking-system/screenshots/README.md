# Screenshots

Add screenshots of the setup sidebar, booking page and Google Sheets menu here.

Before publishing screenshots, remove or blur customer data, email addresses, Calendar IDs, deployment URLs and Stripe information.
